package com.wakescreen.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public class Scheduler {
    public static long nextTrigger(int h, int m) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, h);
        c.set(Calendar.MINUTE, m);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    private static PendingIntent firePi(Context c) {
        return PendingIntent.getBroadcast(c, 1, new Intent(c, WakeReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static long schedule(Context c) {
        Prefs p = new Prefs(c);
        long t = nextTrigger(p.hour(), p.minute());
        schedule(c, t);
        return t;
    }

    public static void schedule(Context c, long t) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent show = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show), firePi(c));
    }

    public static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(firePi(c));
    }

    public static void testIn10s(Context c) {
        schedule(c, System.currentTimeMillis() + 10000);
    }
}
