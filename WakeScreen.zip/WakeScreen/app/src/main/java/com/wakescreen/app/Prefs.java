package com.wakescreen.app;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private final SharedPreferences sp;
    public Prefs(Context c) { sp = c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    public boolean enabled() { return sp.getBoolean("enabled", false); }
    public void setEnabled(boolean v) { sp.edit().putBoolean("enabled", v).apply(); }
    public int hour() { return sp.getInt("hour", 7); }
    public int minute() { return sp.getInt("minute", 0); }
    public void setTime(int h, int m) { sp.edit().putInt("hour", h).putInt("minute", m).apply(); }
    public boolean repeat() { return sp.getBoolean("repeat", true); }
    public void setRepeat(boolean v) { sp.edit().putBoolean("repeat", v).apply(); }
    public int durationSec() { return sp.getInt("dur", 30); }
    public void setDurationSec(int s) { sp.edit().putInt("dur", s).apply(); }
}
