package com.wakescreen.app;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.switchmaterial.SwitchMaterial;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private Prefs p;
    private TextView timeView, status;
    private SwitchMaterial enable, repeat;
    private ChipGroup chips;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        p = new Prefs(this);

        timeView = findViewById(R.id.time);
        status = findViewById(R.id.status);
        enable = findViewById(R.id.enable);
        repeat = findViewById(R.id.repeat);
        chips = findViewById(R.id.chips);

        repeat.setChecked(p.repeat());
        enable.setChecked(p.enabled());
        int d = p.durationSec();
        chips.check(d == 10 ? R.id.c10 : d == 60 ? R.id.c60 : d == 300 ? R.id.c300 : R.id.c30);

        timeView.setOnClickListener(v -> pickTime());
        repeat.setOnCheckedChangeListener((v, on) -> { p.setRepeat(on); apply(); });
        enable.setOnCheckedChangeListener((v, on) -> { p.setEnabled(on); apply(); });
        chips.setOnCheckedStateChangeListener((g, ids) -> {
            if (ids.isEmpty()) return;
            int id = ids.get(0);
            p.setDurationSec(id == R.id.c10 ? 10 : id == R.id.c60 ? 60 : id == R.id.c300 ? 300 : 30);
        });

        ((MaterialButton) findViewById(R.id.test)).setOnClickListener(v -> {
            Scheduler.testIn10s(this);
            Toast.makeText(this, R.string.test_msg, Toast.LENGTH_LONG).show();
        });
        ((MaterialButton) findViewById(R.id.battery)).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));

        refresh();
    }

    private void pickTime() {
        new TimePickerDialog(this, (view, h, m) -> { p.setTime(h, m); apply(); },
                p.hour(), p.minute(), DateFormat.is24HourFormat(this)).show();
    }

    private void apply() {
        if (p.enabled()) Scheduler.schedule(this); else Scheduler.cancel(this);
        refresh();
    }

    private void refresh() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, p.hour());
        c.set(Calendar.MINUTE, p.minute());
        timeView.setText(DateFormat.getTimeFormat(this).format(c.getTime()));
        status.setText(p.enabled()
                ? getString(R.string.status_on, DateFormat.getTimeFormat(this).format(c.getTime()))
                : getString(R.string.status_off));
    }
}
