package com.wakescreen.app;

import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WakeActivity extends AppCompatActivity {
    private final Handler h = new Handler();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_wake);

        ((TextView) findViewById(R.id.clock)).setText(
                new SimpleDateFormat("hh:mm", Locale.getDefault()).format(new Date()));
        findViewById(R.id.dismiss).setOnClickListener(v -> finish());

        int dur = getIntent().getIntExtra("dur", 30);
        h.postDelayed(this::finish, dur * 1000L);
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
